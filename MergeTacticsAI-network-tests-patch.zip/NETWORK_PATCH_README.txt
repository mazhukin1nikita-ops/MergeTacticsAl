MergeTacticsAI network diagnostics patch

Apply from the repository root (the folder that contains MergeTacticsAI/):
  unzip -o MergeTacticsAI-network-tests-patch.zip
  cd MergeTacticsAI
  ./gradlew assembleDebug

If the repository does not contain gradlew, use the existing Gradle wrapper or your normal GitHub Actions workflow.

Patch contains only changed/new files; it is not a full project archive.
Diagnostics are local UI simulations only. They do not change the game's network connection or cancel match results.
