package com.mergetacticsai.automation

import android.graphics.Bitmap
import com.mergetacticsai.accessibility.GestureController
import com.mergetacticsai.ai.Point
import com.mergetacticsai.capture.ScreenCaptureService
import com.mergetacticsai.strategy.CardMemory
import com.mergetacticsai.strategy.AdaptivePlanner
import com.mergetacticsai.strategy.Env
import com.mergetacticsai.strategy.Kind
import com.mergetacticsai.strategy.Line
import com.mergetacticsai.strategy.ContextEvaluator
import com.mergetacticsai.strategy.MatchupInput
import com.mergetacticsai.strategy.UpgradeContext
import com.mergetacticsai.strategy.UpgradeRules
import com.mergetacticsai.odds.OddsParams
import com.mergetacticsai.adapt.Seen
import com.mergetacticsai.journal.JournalWriter
import com.mergetacticsai.sell.SellStore
import com.mergetacticsai.odds.tiersOf
import com.mergetacticsai.strategy.BenchUnit
import com.mergetacticsai.strategy.Build
import com.mergetacticsai.strategy.CycleStrategy
import com.mergetacticsai.strategy.ShopCard
import com.mergetacticsai.strategy.CostCache
import com.mergetacticsai.map.HexCell
import com.mergetacticsai.map.PlacedUnit
import com.mergetacticsai.strategy.HexGrid
import com.mergetacticsai.strategy.PositionContext
import com.mergetacticsai.strategy.PositionEngine
import com.mergetacticsai.strategy.toHex
import com.mergetacticsai.strategy.PlaceGate
import com.mergetacticsai.strategy.SwapPlanner
import com.mergetacticsai.strategy.FieldFixer
import com.mergetacticsai.map.HexMap
import com.mergetacticsai.decision.ActionKind
import com.mergetacticsai.decision.Decision
import com.mergetacticsai.decision.DecisionRecorder
import com.mergetacticsai.decision.Offer
import com.mergetacticsai.decision.Piece
import com.mergetacticsai.decision.Snapshot
import com.mergetacticsai.decision.ValueEngine
import com.mergetacticsai.decision.ValueParams
import com.mergetacticsai.decision.Where
import com.mergetacticsai.strategy.TroopPolicy
import com.mergetacticsai.strategy.LoopKnowledge
import com.mergetacticsai.strategy.TraitEngine
import com.mergetacticsai.vision.OcrReader
import com.mergetacticsai.vision.PixelOps
import com.mergetacticsai.vision.TraitIcons
import com.mergetacticsai.vision.ScreenRegions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Автономный режим без API. Стратегия «круга»: дешёвые с парой → слияние до 2★ → продажа 2★ вне сборки.
 * Решения принимаются по картинке:
 * доступность карточки = не затемнена; объединение = зелёная стрелка над карточкой;
 * результат покупки = картинка карточки изменилась; результат выставления/продажи = слот скамейки опустел.
 */
class LocalLoop(
    private val controller: AgentController,
    private val perms: () -> Permissions,
    private val screen: () -> Pair<Int, Int>,
    private val log: (String) -> Unit,
    private val frame: () -> Bitmap? = { ScreenCaptureService.captureFrame() },
    private val ocr: OcrReader = OcrReader(),
    private val knowledge: () -> LoopKnowledge = { LoopKnowledge.EMPTY },
    private val onUnknownCard: (Long, Bitmap) -> Unit = { _, b -> b.recycle() },
    private val position: () -> PositionContext = { PositionContext() },
    /** Настройки с экрана «Вероятности»: доход, число раундов, места в магазине — по ним бот оценивает сценарии. */
    private val oddsParams: () -> OddsParams = { OddsParams() },
    /** Поправки покупки от анализа соперников (пусто — не влияет). */
    private val adaptBias: () -> Map<String, Double> = { emptyMap() },
    /** Вызывается в начале каждого раунда. */
    private val onRound: (Int) -> Unit = {},
    /** Журнал решений: что бот сделал, почему и чем кончилось. */
    private val journal: JournalWriter? = null,
    /** Журнал попыток продажи с поля: по нему бот сравнивает три способа и выбирает самый надёжный. */
    private val sellStore: SellStore? = null,
    /** База решений: состояние, варианты, ценность до и после, причина, уверенность и итог. */
    private val decisions: DecisionRecorder? = null,
    /** Множители ценности войск по итогам прошлых боёв (пусто — не влияет). Читаются в начале каждого раунда. */
    private val learned: () -> Map<String, Double> = { emptyMap() },
) {
    private class Held(val sig: Long?, val cost: Int?, val trait: String?, val troopId: String?)
    private class PendingBuy(val index: Int, val sig: Long, val cost: Int?, val trait: String?, val troopId: String?, val at: Long, val jid: Long = -1L, val did: Long = -1L)
    private class PendingPlace(val slot: Int, val cell: Int, val at: Long, val unit: PlacedUnit? = null)
    private class PendingSell(val slot: Int, val at: Long, val held: Held?, val jid: Long = -1L, val did: Long = -1L)
    /** Начатая замена: оставшиеся продажи, затем покупка карточки с отпечатком [buySig]. Доводится до конца, пока актуальна. */
    private class Combo(val sales: MutableList<Piece>, val buySig: Long?, val reason: String, val details: String, val until: Long, val did: Long)
    /** Продажа лишнего войска прямо с поля (тянем клетку на зону продажи), чтобы освободить место для бойца сборки. */
    private class PendingBoardSell(val cell: Int, val at: Long, val unit: PlacedUnit)

    /** Лишнее войско уходит с поля на свободный слот скамейки (когда она не полная). */
    private class PendingBoardMove(val cell: Int, val slot: Int, val at: Long, val unit: PlacedUnit)
    /** Боец сборки стоит не на своей клетке по карте — переставляем. */
    private class PendingRelocate(val from: Int, val to: Int, val at: Long, val unit: PlacedUnit)

    /** Краткий статус распознавания для главного экрана. */
    data class Info(val inMatch: Boolean = false, val deploy: Boolean = false, val bench: Int = 0, val bought: Int = 0)
    private val _info = MutableStateFlow(Info())
    val info: StateFlow<Info> = _info

    /** Убирает воина с поля тремя способами с проверкой результата по картинке. */
    private val remover by lazy {
        UnitRemover(AndroidRemoverIO(frame, screen, ocr), sellStore, journal, log, alive = { controller.state.value in active })
    }

    private var job: Job? = null
    private val active = setOf(AgentState.ANALYZING, AgentState.WAITING_FOR_BATTLE)
    private val memory = CardMemory()
    private val costs = CostCache()
    private val costTried = mutableSetOf<Long>()
    private var pendingBuy: PendingBuy? = null
    private var pendingPlace: PendingPlace? = null
    private var pendingSell: PendingSell? = null
    private var pendingBoardSell: PendingBoardSell? = null
    private var pendingBoardMove: PendingBoardMove? = null
    private var pendingRelocate: PendingRelocate? = null
    private var relocFails = 0
    private var lastRelocAt = 0L
    private val relocGiveUp = mutableSetOf<Pair<Int, Int>>()
    private var swapFails = 0
    private var combo: Combo? = null
    private var lastEngineAt = 0L
    private var learnedCache: Map<String, Double> = emptyMap()
    private val valueParams = ValueParams()
    private var lastDecisionLogAt = 0L
    private var lastDecisionText = ""
    private var lastSwapAt = 0L
    private var noVictimLogAt = 0L
    /** Поле, скорее всего, полное: выставление не удалось, а счётчик «N/M» прочитать не получилось. */
    private var boardFullHint = false
    /** Сразу после продажи с поля счётчик на экране ещё показывает старое значение — до этого момента его игнорируем. */
    private var ignoreFullUntil = 0L
    private val badCells = mutableSetOf<Int>()
    /** Кого бот сам выставил на поле: индекс клетки в [HexGrid.cells] → войско. Нужен позиционному ИИ. */
    private val board = HashMap<Int, PlacedUnit>()
    private val placeGate = PlaceGate(4_000)
    private val pairSince = HashMap<Pair<Int, Int>, Long>()
    private val mergeTries = HashMap<Pair<Int, Int>, Int>()
    private val matchCache = HashMap<Long, String?>()
    private var buyFails = 0
    /** Сколько последовательных кадров подтверждают изменение карточки после покупки. */
    private var buyConfirmHits = 0
    private var sellFails = 0
    private var counter: Pair<Int, Int>? = null
    private var counterAt = 0L
    private var lastOrb: Point? = null
    private var orbRepeat = 0
    private var lastDebug = 0L
    private var wasDeploy = false
    private var prevBench = BooleanArray(5)
    private val held = arrayOfNulls<Held>(5)
    private val ownedSigs = mutableListOf<Pair<Long, String>>()
    private var autoBuild = Build(emptySet())
    private var recentBuy: PendingBuy? = null
    private val owned = mutableSetOf<String>()
    private val loggedUnknown = mutableSetOf<Long>()

    // ---- адаптивная стратегия: прокачка, отказ от маловероятного, альтернатива, запас эликсира, смена сборки
    /** Номер текущего раунда матча: растёт каждый раз, когда начинается расстановка. */
    private var roundNo = 0
    /** Номер раунда для других частей приложения. */
    val round: Int get() = roundNo
    /** Сколько копий каждого войска у нас сейчас (скамейка и поле, без 3★) и что стоит на поле. Нужны анализу соперников. */
    @Volatile var ownCopies: Map<String, Int> = emptyMap(); private set
    @Volatile var ownBoard: List<Seen> = emptyList(); private set
    /** Войска, дособирать которые бот бросил (накапливается за матч, чтобы не покупать и не продавать по кругу). */
    private val abandoned = mutableSetOf<String>()
    private var elixirCache: Pair<Int, Long>? = null
    private var lastPivotAt = 0L
    private var lastPlan = ""
    private var lastPlanAt = 0L
    private var lastEvalAt = 0L

    fun stop() { job?.cancel(); job = null }

    fun start(scope: CoroutineScope) {
        stop()
        memory.clear(); pendingBuy = null; pendingPlace = null; pendingSell = null
        combo = null; lastEngineAt = 0L; learnedCache = emptyMap(); decisions?.newSession()
        pendingBoardSell = null; swapFails = 0; lastSwapAt = 0L; noVictimLogAt = 0L; boardFullHint = false; ignoreFullUntil = 0L
        pendingBoardMove = null; pendingRelocate = null; relocFails = 0; lastRelocAt = 0L; relocGiveUp.clear()
        badCells.clear(); board.clear(); placeGate.reset(); pairSince.clear(); mergeTries.clear(); matchCache.clear()
        buyFails = 0; buyConfirmHits = 0; sellFails = 0; counter = null
        lastOrb = null; orbRepeat = 0; wasDeploy = false
        prevBench = BooleanArray(5); held.fill(null); recentBuy = null
        ownedSigs.clear(); autoBuild = Build(emptySet())
        owned.clear(); loggedUnknown.clear()
        Timing.reset(); roundNo = 0; abandoned.clear(); elixirCache = null; lastPivotAt = 0L; lastPlan = ""; lastPlanAt = 0L; lastEvalAt = 0L
        _info.value = Info()
        job = scope.launch(Dispatchers.Default) { loop() }
    }

    private suspend fun loop() {
        while (true) {
            delay(Timing.LOOP_MS)
            val st = controller.state.value
            if (st !in active) {
                if (st == AgentState.STOPPED || st == AgentState.ERROR) break
                continue
            }
            if (!perms().capture) {
                log("Захват экрана потерян — остановка")
                controller.transition(AgentState.ERROR); break
            }
            val bmp = frame() ?: continue
            try {
                com.mergetacticsai.record.ScreenRecorder.onFrame(bmp)
                step(bmp)
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) {
                log("Ошибка шага: ${e.message}"); delay(1000)
            } finally {
                bmp.recycle()
            }
        }
    }

    private inline fun act(block: () -> Boolean): Boolean {
        if (!controller.transition(AgentState.PLANNING)) return false
        if (!controller.transition(AgentState.EXECUTING)) { controller.transition(AgentState.ANALYZING); return false }
        val ok = block()
        controller.transition(AgentState.ANALYZING)
        return ok
    }

    /** Сферы любого цвета, в расстановке и в бою. */
    private suspend fun handleOrb(bmp: Bitmap): Boolean {
        val o = PixelOps.findOrb(bmp)
        if (o == null) { lastOrb = null; orbRepeat = 0; return false }
        if (!perms().canControlGame) return false
        val last = lastOrb
        if (last != null && abs(last.x - o.x) < 0.05f && abs(last.y - o.y) < 0.05f) orbRepeat++ else orbRepeat = 0
        lastOrb = o
        if (orbRepeat >= 3) return false
        val (w, h) = screen()
        val ok = GestureController.tap(o.x * w, o.y * h)
        if (ok) log("Нажимаю на сферу")
        delay(120)
        return ok
    }

    /** Следим, какая карточка попала в какой слот скамейки (нужно, чтобы знать свойство и цену юнита). */
    private fun trackBench(bench: BooleanArray, now: Long) {
        for (i in 0 until 5) {
            if (!bench[i]) held[i] = null
            else if (!prevBench[i]) {
                val rb = recentBuy
                held[i] = if (rb != null && now - rb.at < 4000) Held(rb.sig, rb.cost, rb.trait, rb.troopId) else null
            }
        }
        prevBench = bench.copyOf()
        _info.value = _info.value.copy(bench = bench.count { it }, bought = ownedSigs.size)
    }

    private var planDetails = ""
    private var planReason = ""

    private fun keyName(key: String, k: LoopKnowledge): String = k.troops[key]?.name ?: "войско без названия"

    private fun decisionDetails(s: List<com.mergetacticsai.strategy.Scenario>, bias: Map<String, Double>, env: Env): String =
        buildString {
            appendLine("Эликсир: ${env.elixir ?: "не прочитан"}, доход: ${env.income}, раундов осталось: ${env.roundsLeft}")
            s.sortedByDescending { it.value }.forEach { appendLine("Сценарий: ${it.label} — ${AdaptivePlanner.fmt(it.value)}") }
            if (bias.isNotEmpty()) appendLine("Поправки по соперникам действуют на ${bias.size} карт(ы)")
            append("Шансы выпадения и сила звёзд — допущения, не проверенные по игре")
        }

    private fun close(a: Long, b: Long) = java.lang.Long.bitCount(a xor b) <= CardMemory.MAX_DIST

    /** Сколько разных войск каждого свойства куплено (дубликаты — это слияния и считаются один раз). */
    private fun ownedTraitCounts(): Map<String, Int> = ownedSigs.map { it.second }.filter { it.isNotEmpty() }.groupingBy { it }.eachCount()

    private fun traitName(id: String, k: LoopKnowledge) = k.traits.firstOrNull { it.id == id }?.name ?: id

    /** После подтверждённой покупки: учитываем войско и показываем прогресс синергии. */
    private fun onBought(p: PendingBuy) {
        val k = knowledge()
        if (ownedSigs.none { close(it.first, p.sig) }) ownedSigs += p.sig to (p.trait ?: "")
        p.troopId?.let { owned += it }
        // Цена — это эликсир (капля на карточке), свойство — значок на карточке, а число войск свойства — отдельная величина.
        val name = p.troopId?.let { k.troops[it]?.name } ?: "карточка ${p.index + 1}"
        val price = p.cost?.let { "цена $it эликсира" } ?: "цена не прочитана"
        val trait = p.trait?.takeIf { it.isNotEmpty() }
        if (trait == null) { log("Куплено: «$name», $price"); return }
        val c = ownedTraitCounts()[trait] ?: 0
        val tiers = k.traits.firstOrNull { it.id == trait }?.tiers ?: emptyList()
        val next = tiers.firstOrNull { it > c }
        log("Куплено: «$name», $price, свойство «${traitName(trait, k)}». " +
            "Разных войск этого свойства в команде: $c" + (next?.let { ", до порога $it нужно ещё ${it - c}" } ?: ", порог максимальный"))
    }

    /** Узнаём войско по эталонам из фото каталога; результат запоминаем по отпечатку карточки. */
    private fun matchTroop(k: LoopKnowledge, sig: Long, bmp: Bitmap, index: Int): com.mergetacticsai.data.Troop? {
        val m = k.matcher ?: return null
        val cached = matchCache.entries.firstOrNull { close(it.key, sig) }
        val id = if (cached != null) cached.value else m.match(bmp, index).also { matchCache[sig] = it }
        return id?.let { k.troops[it] }
    }

    private fun currentBuild(k: LoopKnowledge): Build {
        val sel = k.policy.traits
        if (k.placeSel.isNotEmpty()) return Build(sel, k.placeSel)
        if (sel.isNotEmpty()) return Build(sel)
        if (!autoBuild.found) {
            val found = CycleStrategy.detectBuild(emptySet(), ownedTraitCounts())
            if (found.found) {
                autoBuild = found
                log("Сборка найдена: " + found.traits.joinToString { traitName(it, k) })
            }
        }
        return autoBuild
    }

    /** Идентификатор войска для поля: настоящий id, а если карточка не узнана — по свойству со значка ("trait:clan"). */
    private fun idOf(troopId: String?, trait: String?): String? =
        troopId ?: trait?.takeIf { it.isNotEmpty() }?.let { FieldFixer.pseudoId(it) }

    private fun unitName(k: LoopKnowledge, u: PlacedUnit): String =
        k.troops[u.troopId]?.name ?: if (FieldFixer.isPseudo(u.troopId)) "войско (${traitName(u.troopId.removePrefix(FieldFixer.TRAIT_PREFIX), k)})" else u.troopId

    private fun heldFor(u: PlacedUnit, k: LoopKnowledge): Held =
        if (FieldFixer.isPseudo(u.troopId)) Held(null, null, u.troopId.removePrefix(FieldFixer.TRAIT_PREFIX), null)
        else Held(null, k.troops[u.troopId]?.cost, k.troops[u.troopId]?.trait?.takeIf { it.isNotEmpty() }, u.troopId)

    /** Эликсир с экрана: читаем не чаще раза в 1,2 с; после покупки значение уменьшаем на цену. */
    private suspend fun elixirNow(bmp: Bitmap, now: Long): Int? {
        val c = elixirCache
        if (c != null && now - c.second < 1200) return c.first
        val e = ocr.readElixir(bmp)
        elixirCache = if (e != null) e to now else null
        return e
    }

    /** Ключ войска для подсчёта копий: настоящий id, а если карточка не узнана — по отпечатку. */
    private fun repKey(sig: Long): String = "sig:" + (ownedSigs.firstOrNull { close(it.first, sig) }?.first ?: sig)

    private fun benchKey(i: Int): String? {
        val h = held[i] ?: return null
        return h.troopId ?: h.sig?.let { repKey(it) }
    }

    private class Acc(val key: String, val troopId: String?, val trait: String?, val cost: Int?) {
        var ones = 0
        var twos = 0
    }

    /** Линии прокачки: сколько копий каждого войска у нас на скамейке и на поле. */
    private fun buildLines(k: LoopKnowledge, bench: BooleanArray, twoStar: BooleanArray): List<Line> {
        val acc = LinkedHashMap<String, Acc>()
        for (i in 0 until 5) {
            if (!bench[i]) continue
            val key = benchKey(i) ?: continue
            val h = held[i]
            val a = acc.getOrPut(key) { Acc(key, h?.troopId, h?.trait, h?.cost) }
            if (twoStar[i]) a.twos++ else a.ones++
        }
        for (u in board.values) {
            if (FieldFixer.isPseudo(u.troopId) || u.stars >= 3) continue
            val t = k.troops[u.troopId]
            val a = acc.getOrPut(u.troopId) { Acc(u.troopId, u.troopId, t?.trait?.takeIf { it.isNotEmpty() }, t?.cost) }
            if (u.stars >= 2) a.twos++ else a.ones++
        }
        return acc.values.map { Line(it.key, it.troopId, it.trait, it.cost, it.ones, it.twos) }
    }

    private suspend fun step(bmp: Bitmap) {
        val inMatch = (0 until 5).count { PixelOps.woodFraction(bmp, it) >= 0.15f } >= 4
        if (_info.value.inMatch != inMatch) _info.value = _info.value.copy(inMatch = inMatch)
        if (!inMatch) {
            if (roundNo != 0) { roundNo = 0; abandoned.clear(); elixirCache = null; combo = null; decisions?.newSession() }
            return
        }
        if (handleOrb(bmp)) return

        val deploy = PixelOps.deployIconFraction(bmp) >= 0.2f
        if (_info.value.deploy != deploy) _info.value = _info.value.copy(deploy = deploy)
        if (!deploy) {
            controller.transition(AgentState.WAITING_FOR_BATTLE)
            if (wasDeploy) {
                wasDeploy = false
                badCells.clear(); placeGate.reset(); pairSince.clear(); mergeTries.clear()
                pendingBuy = null; pendingPlace = null; pendingSell = null
                pendingBoardSell = null; swapFails = 0; boardFullHint = false; ignoreFullUntil = 0L
                pendingBoardMove = null; pendingRelocate = null; relocFails = 0; relocGiveUp.clear()
                sellFails = 0; counter = null; combo = null
            }
            return
        }
        controller.transition(AgentState.ANALYZING)
        if (!wasDeploy) {
            roundNo++; journal?.setRound(roundNo); decisions?.setRound(roundNo)
            learnedCache = runCatching { learned() }.getOrDefault(emptyMap())
            runCatching { onRound(roundNo) }
        }
        wasDeploy = true
        if (!perms().canControlGame) return

        val now = System.currentTimeMillis()
        val bench = BooleanArray(5) { PixelOps.woodFraction(bmp, it) < 0.9f }
        trackBench(bench, now)
        val sigs = LongArray(3) { PixelOps.cardSignature(bmp, it) }
        val afford = BooleanArray(3) { PixelOps.cardAffordable(bmp, it) }
        val arrow = BooleanArray(3) { PixelOps.cardMergeArrow(bmp, it) }

        if (now - lastDebug > 5000) {
            lastDebug = now
            val e = ocr.readElixir(bmp)
            log("Вижу: эликсир=${e ?: "?"}, доступно=${afford.joinToString("") { if (it) "✓" else "✗" }}, стрелки=${arrow.joinToString("") { if (it) "↑" else "·" }}, скамейка=${bench.count { it }}/5, поле=${counter?.let { "${it.first}/${it.second}" } ?: "?"}")
        }

        // Проверка покупки: сначала ждём изменения, затем подтверждаем его вторым кадром.
        // После любого результата текущий кадр больше не используется для нового решения:
        // следующий цикл обязан построить новый snapshot.
        pendingBuy?.let { p ->
            val changed = java.lang.Long.bitCount(p.sig xor sigs[p.index]) > CardMemory.MAX_DIST
            if (changed) {
                buyConfirmHits++
                if (buyConfirmHits >= 2) {
                    memory.recordBuy(p.sig)
                    onBought(p)
                    recentBuy = PendingBuy(p.index, p.sig, p.cost, p.trait, p.troopId, System.currentTimeMillis())
                    journal?.outcome(p.jid, true, "покупка подтверждена двумя последовательными кадрами")
                    decisions?.outcome(p.did, true, "покупка подтверждена двумя последовательными кадрами")
                    buyFails = 0
                    buyConfirmHits = 0
                    pendingBuy = null
                    Timing.ok()
                    // Не доверяем старому OCR после действия. Следующий цикл прочитает эликсир заново.
                    elixirCache = null
                    return
                }
            } else {
                buyConfirmHits = 0
            }
            if (now - p.at > 1500) {
                journal?.outcome(p.jid, false, "покупка не подтверждена за 1,5 с")
                decisions?.outcome(p.did, false, "покупка не подтверждена за 1,5 с")
                buyFails++
                buyConfirmHits = 0
                pendingBuy = null
                Timing.fail()
                // После неудачи тоже нужен новый snapshot.
                elixirCache = null
                return
            } else return
        }
        if (buyFails >= 3) {
            log("Тап по карточке не покупает юнита — возможно, нужно перетаскивание. Пауза.")
            buyFails = 0; controller.transition(AgentState.PAUSED); return
        }
        // Проверка выставления: слот скамейки должен опустеть. Неудача — пауза 20 секунд.
        pendingPlace?.let { p ->
            if (!bench[p.slot]) {
                placeGate.onSuccess(); Timing.ok(); p.unit?.let { board[p.cell] = it }; pendingPlace = null
                counter = null; counterAt = 0L
                return
            } else if (now - p.at > 1200) {
                badCells += p.cell; pendingPlace = null; placeGate.onFail(); boardFullHint = true; Timing.fail()
                log("Не получилось поставить на поле — повторю после нового сканирования")
                return
            } else return
        }
        // Проверка продажи.
        pendingSell?.let { p ->
            if (!bench[p.slot]) {
                journal?.outcome(p.jid, true, "слот скамейки опустел — продано")
                decisions?.outcome(p.did, true, "слот скамейки опустел — продано")
                sellFails = 0; pendingSell = null; elixirCache = null; Timing.ok(); log("Продан лишний юнит")
                val hs = p.held?.sig
                if (hs != null && held.none { it?.sig != null && close(it.sig, hs) }) ownedSigs.removeAll { close(it.first, hs) }
                return
            }
            else if (now - p.at > 1200) { journal?.outcome(p.jid, false, "слот не опустел за 1,2 с — продажа не подтверждена"); decisions?.outcome(p.did, false, "слот не опустел за 1,2 с — продажа не подтверждена"); combo = null; sellFails++; pendingSell = null; Timing.fail()
                elixirCache = null
                return
            }
            else return
        }
        // Проверка продажи с поля: полоска здоровья над клеткой должна исчезнуть.
        pendingBoardSell?.let { p ->
            if (!PixelOps.cellOccupied(bmp, HexGrid.cells[p.cell])) {
                board.remove(p.cell); pendingBoardSell = null; swapFails = 0; boardFullHint = false
                placeGate.reset(); counter = null; counterAt = 0L; ignoreFullUntil = now + 800; lastSwapAt = now
                log("Убрал с поля «${knowledge().troops[p.unit.troopId]?.name ?: p.unit.troopId}» — место свободно")
                return
            } else if (now - p.at > 1500) {
                swapFails++; pendingBoardSell = null
                log("Не удалось убрать войско с поля (попытка $swapFails из 3)")
            } else return
        }

        // Проверка переноса лишнего с поля на скамейку: клетка пуста, слот скамейки занят.
        pendingBoardMove?.let { p ->
            val moved = !PixelOps.cellOccupied(bmp, HexGrid.cells[p.cell]) && bench[p.slot]
            if (moved) {
                board.remove(p.cell); pendingBoardMove = null; swapFails = 0; boardFullHint = false
                placeGate.reset(); counter = null; counterAt = 0L; ignoreFullUntil = now + 800; lastSwapAt = now
                held[p.slot] = heldFor(p.unit, knowledge())
                log("Убрал «${unitName(knowledge(), p.unit)}» с поля на скамейку — место свободно")
                return
            } else if (now - p.at > 1500) {
                swapFails++; pendingBoardMove = null
                log("Не удалось перенести войско с поля на скамейку (попытка $swapFails из 3)")
            } else return
        }
        // Проверка перестановки по карте: старая клетка пуста, новая занята.
        pendingRelocate?.let { p ->
            val gone = !PixelOps.cellOccupied(bmp, HexGrid.cells[p.from])
            val there = PixelOps.cellOccupied(bmp, HexGrid.cells[p.to])
            if (gone && there) {
                board.remove(p.from); board[p.to] = p.unit; pendingRelocate = null; relocFails = 0
                log("Войско теперь на своей клетке по карте (${HexMap.label(HexGrid.cells[p.to].toHex())})")
                return
            } else if (now - p.at > 1200) {
                relocGiveUp += p.from to p.to; relocFails++; pendingRelocate = null
                log("Не удалось переставить войско на клетку по карте (попытка $relocFails из 3)")
            } else return
        }

        val (w, h) = screen()
        val k = knowledge()
        val build = currentBuild(k)
        val twoStar = BooleanArray(5) { PixelOps.benchTwoStar(bmp, it) }
        val benchUnits: List<BenchUnit?> = (0 until 5).map { i ->
            if (!bench[i]) null else BenchUnit(i, held[i]?.sig, held[i]?.cost, held[i]?.trait, held[i]?.troopId, twoStar[i])
        }

        // Карточки магазина: цена, свойство (из «Обучения» или по значку), допуск по выбору пользователя.
        val cards = (0..2).map { i ->
            val troop = k.known.lookup(sigs[i])?.let { k.troops[it] } ?: matchTroop(k, sigs[i], bmp, i)
            if (troop == null && sigs[i] !in loggedUnknown) {
                loggedUnknown += sigs[i]
                onUnknownCard(sigs[i], PixelOps.cardCrop(bmp, i))
            }
            val trait = troop?.trait?.takeIf { it.isNotEmpty() } ?: TraitIcons.classify(bmp, i)
            var cost = troop?.cost ?: costs.get(sigs[i])
            if (cost == null && afford[i] && sigs[i] !in costTried) {
                costTried += sigs[i]
                cost = ocr.readCost(bmp, i)?.also { costs.put(sigs[i], it) }
            }
            val pol = k.policy
            val allowed = when {
                !pol.strict || arrow[i] -> true
                pol.traits.isNotEmpty() && trait != null -> trait in pol.traits && (troop == null || troop.id in pol.enabled)
                else -> pol.allows(troop, false)
            }
            ShopCard(i, sigs[i], cost, trait, troop?.id, afford[i], arrow[i], allowed)
        }

        // 0) Две одинаковые 1★ на скамейке не слились за 4 секунды — тянем один на другого.
        val seenPairs = HashSet<Pair<Int, Int>>()
        for (i in 0 until 5) for (j in i + 1 until 5) {
            val si = held[i]?.sig; val sj = held[j]?.sig
            if (!bench[i] || !bench[j] || si == null || sj == null || !close(si, sj) || twoStar[i] || twoStar[j]) continue
            val key = i to j
            seenPairs += key
            val since = pairSince.getOrPut(key) { now }
            if (now - since > 4000 && (mergeTries[key] ?: 0) < 2) {
                mergeTries[key] = (mergeTries[key] ?: 0) + 1
                val ok = act {
                    GestureController.drag(ScreenRegions.benchX[i] * w, ScreenRegions.BENCH_Y * h,
                        ScreenRegions.benchX[j] * w, ScreenRegions.BENCH_Y * h)
                }
                if (ok) log("Слияние не произошло само — сливаю слоты ${i + 1} и ${j + 1}")
                pairSince[key] = now
                delay(Timing.AFTER_MS); return
            }
        }
        pairSince.keys.retainAll(seenPairs)

        // 1) Выставляем со скамейки на поле по сетке: только на свободные клетки, не чаще раза в 20 с после неудачи.
        val slot = CycleStrategy.pickPlacement(benchUnits, build, k.placeSel)
        val wanted = slot?.let { benchUnits[it] }
        val wantedInBuild = wanted != null && CycleStrategy.inBuild(wanted.trait, wanted.troopId, build)
        if (slot != null && placeGate.canTry()) {
            if (now - counterAt > 800) { counter = ocr.readCounter(bmp); counterAt = System.currentTimeMillis() }
            val c = counter
            if (c != null && c.first >= c.second && now >= ignoreFullUntil) {
                placeGate.onFail()
                log("Поле заполнено (${c.first}/${c.second}) — следующая попытка через 4 с")
            } else {
                val occupied = HexGrid.cells.map { PixelOps.cellOccupied(bmp, it) }
                board.keys.retainAll { occupied[it] }
                val bu = benchUnits[slot]
                val tid = bu?.let { idOf(it.troopId, it.trait) }
                val unit = if (bu != null && tid != null) PlacedUnit(tid, if (bu.twoStar) 2 else 1) else null
                val ownBoard: Map<HexCell, PlacedUnit> = board.entries.associate { HexGrid.cells[it.key].toHex() to it.value }
                val target = PositionEngine.pickGridCell(unit, occupied, badCells, ownBoard, position())
                if (target == null) {
                    placeGate.onFail()
                    log("Нет свободных клеток на поле — следующая попытка через 4 с")
                } else {
                    val ix = HexGrid.indexOf(target)
                    val ok = act { GestureController.drag(ScreenRegions.benchX[slot] * w, ScreenRegions.BENCH_Y * h, target.x * w, target.y * h) }
                    if (ok) {
                        log("Выставляю на поле (ряд ${target.row - HexGrid.FIRST_ROW + 1}, клетка ${target.col + 1})" + if (twoStar[slot]) " 2★" else "")
                        pendingPlace = PendingPlace(slot, ix, System.currentTimeMillis(), unit)
                    }
                    delay(Timing.AFTER_MS); return
                }
            }
        }

        // 1б) Боец сборки стоит не на своей клетке по карте — переставляем на свободную клетку по плану.
        val planNow = position().plan
        if (planNow.isNotEmpty() && pendingRelocate == null && pendingBoardSell == null && pendingBoardMove == null &&
            relocFails < 3 && now - lastRelocAt > 1000
        ) {
            val occ = HexGrid.cells.map { PixelOps.cellOccupied(bmp, it) }
            board.keys.retainAll { it in occ.indices && occ[it] }
            val rel = FieldFixer.pickRelocation(board, occ, planNow, badCells, relocGiveUp)
            if (rel != null) {
                lastRelocAt = now
                val from = HexGrid.cells[rel.fromIx]; val to = HexGrid.cells[rel.toIx]
                val ok = act { GestureController.drag(from.x * w, from.y * h, to.x * w, to.y * h) }
                if (ok) {
                    log("«${unitName(k, rel.unit)}» стоит не по карте — переставляю на ${HexMap.label(to.toHex())}")
                    pendingRelocate = PendingRelocate(rel.fromIx, rel.toIx, now, rel.unit)
                }
                delay(Timing.AFTER_MS); return
            }
        }

        // 2–3) Единый расчёт ценности (decision/ValueEngine): купить, продать, заменить или ничего не менять.
        //      Случайности нет: при том же состоянии поля, магазина, эликсира и сборки решение то же самое.
        val benchHasSpace = bench.any { !it }
        val op = oddsParams()
        val env = Env(
            elixir = elixirNow(bmp, now), income = op.income,
            roundsLeft = (op.rounds - roundNo + 1).coerceAtLeast(1),
            shopSlots = op.shopSlots, tiers = tiersOf(k.troops.values.toList()), weights = op.weights,
        )
        val lines = buildLines(k, bench, twoStar)

        // Смена направления сборки: только для найденной автоматически, выбор пользователя не трогаем.
        if (k.policy.traits.isEmpty() && k.placeSel.isEmpty() && autoBuild.found && now - lastPivotAt > 30000) {
            val pv = AdaptivePlanner.pivot(lines, cards, autoBuild, env)
            if (pv != null) {
                log("Меняю направление сборки: " + autoBuild.traits.joinToString { traitName(it, k) } + " → " +
                    pv.build.traits.joinToString { traitName(it, k) } +
                    " (оценка " + AdaptivePlanner.fmt(pv.valueNow) + " → " + AdaptivePlanner.fmt(pv.valueNew) + ")")
                journal?.log("PIVOT", "Смена направления сборки",
                    "Другое свойство заметно выгоднее по оценке сценариев: " + AdaptivePlanner.fmt(pv.valueNow) + " → " + AdaptivePlanner.fmt(pv.valueNew) + " (порог разницы " + AdaptivePlanner.PIVOT_MARGIN + ").",
                    "Было: " + autoBuild.traits.joinToString { traitName(it, k) } + "\nСтало: " + pv.build.traits.joinToString { traitName(it, k) }, "DONE")
                autoBuild = pv.build
                lastPivotAt = now
            }
        }
        val buildNow = currentBuild(k)
        ownCopies = lines.mapNotNull { l -> l.troopId?.let { it to (l.ones + 2 * l.twos) } }.toMap()
        ownBoard = board.values.filter { !FieldFixer.isPseudo(it.troopId) }.map { Seen(it.troopId, it.stars) }
        // Оценка прокачки: звёздность, копии, пул, шанс, цена и сила улучшения по каждому войску.
        if (lines.isNotEmpty() && now - lastEvalAt > 15000) {
            lastEvalAt = now
            val posCtx = position()
            val boardLayout: Map<HexCell, PlacedUnit> = board.entries.associate { HexGrid.cells[it.key].toHex() to it.value }
            val uctx = UpgradeContext(
                lines = lines, build = buildNow,
                traitTiers = k.traits.associate { it.id to it.tiers },
                names = { id -> k.traits.firstOrNull { it.id == id }?.name ?: id },
                ruler = posCtx.combat.ruler, modifiers = posCtx.combat.modifiers,
                matchup = if (posCtx.enemy.isNotEmpty()) MatchupInput(boardLayout + posCtx.enemy, posCtx.stats, posCtx.combat) else null,
            )
            val top = ContextEvaluator.rank(uctx, env, UpgradeRules.from(op)) { l -> l.troopId?.let { k.troops[it]?.name } ?: "войско" }.take(3)
            log("Оценка прокачки: " + top.joinToString(" | ") { ContextEvaluator.describe(it) })
            journal?.log("EVAL", "Оценка прокачки", "Плановая оценка войск: звёздность, копии, пул, шанс, цена, сила и контекст.",
                top.joinToString("\n") { ContextEvaluator.describe(it) }, "INFO", dedupKey = "eval")
        }
        // Замена, начатая раньше (продажа → покупка), доводится до конца, пока она актуальна.
        if (runCombo(k, cards, bench, bmp, w, h, now)) return

        if (now - lastEngineAt < Timing.ENGINE_GAP_MS) return
        lastEngineAt = now
        val occupied = HexGrid.cells.map { PixelOps.cellOccupied(bmp, it) }
        board.keys.retainAll { it in occupied.indices && occupied[it] }
        if (now - counterAt > 800) { counter = ocr.readCounter(bmp); counterAt = System.currentTimeMillis() }
        val snap = buildSnapshot(k, bench, twoStar, cards, occupied, env, buildNow, now)
        val d = ValueEngine.decide(snap, valueParams)
        val did = decisions?.record(snap, d) ?: -1L
        val details = decisionDetails(d, snap)
        val text = d.kind.name + d.reason
        if (text != lastDecisionText || now - lastDecisionLogAt > 6000) {
            lastDecisionText = text; lastDecisionLogAt = now
            log("Решение: " + d.reason)
        }
        when (d.kind) {
            ActionKind.NONE -> {
                if (did >= 0) journal?.log("DECISION", "Ничего не менять", d.reason, details, "INFO", dedupKey = "none-" + d.reason)
                return
            }
            ActionKind.BUY -> {
                val o = d.buy ?: return
                val card = cards.getOrNull(o.index) ?: return
                buyCard(k, card, w, h, d.reason, details, did)
                return
            }
            ActionKind.SELL, ActionKind.SELL_AND_BUY -> {
                val rest = d.sales.map { it.piece }.toMutableList()
                if (rest.isEmpty()) return
                val first = rest.removeAt(0)
                val buySig = d.buy?.let { o -> cards.getOrNull(o.index)?.sig }
                combo = if (buySig != null || rest.isNotEmpty()) Combo(rest, buySig, d.reason, details, now + 12000, did) else null
                sellPiece(k, first, d.reason, details, did, bmp, w, h, now)
                return
            }
        }
    }

    /** Состояние для расчёта: что на поле (то, что бот выставил сам), на скамейке, в магазине, эликсир, сборка и карта. */
    private fun buildSnapshot(
        k: LoopKnowledge, bench: BooleanArray, twoStar: BooleanArray, cards: List<ShopCard>, occupied: List<Boolean>,
        env: Env, build: Build, now: Long,
    ): Snapshot {
        val pos = position()
        val plan = pos.plan
        val pieces = ArrayList<Piece>()
        var known = 0
        for ((ix, u) in board.toSortedMap()) {
            if (ix !in occupied.indices || !occupied[ix]) continue
            val pseudo = FieldFixer.isPseudo(u.troopId)
            val troop = if (pseudo) null else k.troops[u.troopId]
            val trait = if (pseudo) u.troopId.removePrefix(FieldFixer.TRAIT_PREFIX) else troop?.trait?.takeIf { it.isNotEmpty() }
            val planned = SwapPlanner.planned(plan, u.troopId)
            pieces += Piece(Where.FIELD, ix, if (pseudo) null else u.troopId, trait, troop?.cost, u.stars, HexGrid.cells[ix].toHex() in planned, planned.isNotEmpty())
            known++
        }
        val fieldUnknown = (occupied.count { it } - known).coerceAtLeast(0)
        for (i in 0 until 5) {
            if (!bench[i]) continue
            val h = held[i]
            val tid = h?.troopId
            val t = tid?.let { k.troops[it] }
            val trait = h?.trait ?: t?.trait?.takeIf { it.isNotEmpty() }
            val hasCell = tid != null && SwapPlanner.planned(plan, tid).isNotEmpty()
            pieces += Piece(Where.BENCH, i, tid, trait, h?.cost ?: t?.cost, if (twoStar[i]) 2 else 1, false, hasCell)
        }
        val offers = cards.map { Offer(it.index, it.troopId, it.trait, it.cost, it.affordable, it.arrow, it.allowed) }
        // Относительная сила по введённым HP, урону и скорости ударов (если все они заданы).
        val valid = pos.stats.filterValues { it.valid }
        val statPower = HashMap<String, Double>()
        if (valid.isNotEmpty()) {
            val raw = valid.mapValues { Math.sqrt((it.value.hp * it.value.dps).toDouble()) }
            val mean = raw.values.average()
            if (mean > 0.0) for ((id, v) in raw) statPower[id] = v / mean
        }
        val noSell = HashSet<String>()
        if (swapFails >= 3 || now - lastSwapAt < 600) pieces.filter { it.where == Where.FIELD }.forEach { noSell += it.key }
        if (sellFails >= 3) pieces.filter { it.where == Where.BENCH }.forEach { noSell += it.key }
        val ruler = pos.combat.ruler
        val extra = HashMap<String, Int>()
        if (ruler == "goblin_queen") extra["goblin"] = 1
        if (ruler == "tomb_queen") extra["undead"] = 1
        return Snapshot(
            pieces = pieces, offers = offers, elixir = env.elixir, benchSlots = 5,
            fieldLimit = counter?.second, fieldUnknown = fieldUnknown, build = build, env = env,
            traitTiers = { t -> k.traits.firstOrNull { it.id == t }?.tiers?.takeIf { it.isNotEmpty() } ?: TroopPolicy.thresholds(t) },
            statPower = statPower, bias = adaptBias(), learned = learnedCache,
            mergeBonus = if (ruler == "spirit_empress") 1 else 0, extraTraitCounts = extra, noSell = noSell, fieldFullHint = boardFullHint,
        )
    }

    private fun decisionDetails(d: Decision, s: Snapshot): String = buildString {
        appendLine("Эликсир: ${s.elixir ?: "не прочитан"}; на поле: ${s.pieces.count { it.where == Where.FIELD }} из ${s.fieldLimit ?: "?"}, неопознанных: ${s.fieldUnknown}")
        appendLine("Ценность состава: ${ValueEngine.fmt(d.before.total)} → ${ValueEngine.fmt((d.after ?: d.before).total)}")
        d.lines.forEach { appendLine("Вариант: $it") }
        if (d.gainedTiers.isNotEmpty()) appendLine("Получаем свойства: " + d.gainedTiers.joinToString())
        if (d.lostTiers.isNotEmpty()) appendLine("Теряем свойства: " + d.lostTiers.joinToString())
        appendLine("Уверенность: ${(d.confidence * 100).toInt()}%")
        append("Правило продажи (цена − 1) проверено по игре; сила войск, шансы и цена эликсира — допущения")
    }

    private suspend fun buyCard(k: LoopKnowledge, pc: ShopCard, w: Int, h: Int, reason: String, details: String, did: Long) {
        val pick = pc.index
        val ok = act { GestureController.tap(ScreenRegions.cardX[pick] * w, ScreenRegions.CARD_Y * h) }
        if (ok) {
            log("Покупаю карточку ${pick + 1}" + (pc.troopId?.let { " «" + (k.troops[it]?.name ?: it) + "»" } ?: "") +
                ": цена " + (pc.cost?.let { "$it эликсира" } ?: "не прочитана") +
                (pc.trait?.let { ", свойство «${traitName(it, k)}»" } ?: "") + (if (pc.arrow) " (слияние)" else ""))
            val jid = journal?.log("BUY", "Покупка: карточка ${pick + 1}" + (pc.troopId?.let { " «" + (k.troops[it]?.name ?: it) + "»" } ?: ""),
                reason, "Цена: ${pc.cost?.let { "$it эликсира" } ?: "не прочитана"}\nСвойство: ${pc.trait?.let { traitName(it, k) } ?: "не определено"}\nСлияние: ${pc.arrow}\n" + details, "PLANNED") ?: -1L
            buyConfirmHits = 0
            pendingBuy = PendingBuy(pick, pc.sig, pc.cost, pc.trait, pc.troopId, System.currentTimeMillis(), jid, did)
        }
        delay(Timing.AFTER_MS)
    }

    /** Продаёт одно войско: со скамейки — перетаскиванием на зону продажи, с поля — через [UnitRemover] с проверкой по картинке. */
    private suspend fun sellPiece(k: LoopKnowledge, p: Piece, reason: String, details: String, did: Long, bmp: Bitmap, w: Int, h: Int, now: Long) {
        val name = p.troopId?.let { k.troops[it]?.name } ?: "войско"
        if (p.where == Where.BENCH) {
            val slot = p.index
            val ok = act {
                GestureController.drag(ScreenRegions.benchX[slot] * w, ScreenRegions.BENCH_Y * h, ScreenRegions.SELL_X * w, ScreenRegions.SELL_Y * h)
            }
            if (ok) {
                log("Слот ${slot + 1}: продаю «$name» — $reason")
                val jid = journal?.log("SELL", "Продажа: слот ${slot + 1} «$name»", reason, details, "PLANNED") ?: -1L
                pendingSell = PendingSell(slot, System.currentTimeMillis(), held[slot], jid, did)
            }
            delay(Timing.AFTER_MS)
            return
        }
        val unit = board[p.index]
        if (unit == null) {
            decisions?.outcome(did, false, "войско на поле не найдено"); combo = null
            return
        }
        val cell = HexGrid.cells[p.index]
        val where = "ряд ${cell.row - HexGrid.FIRST_ROW + 1}, клетка ${cell.col + 1}"
        lastSwapAt = now
        val res = remover.remove(RemoveRequest(cellIndex = p.index, unitId = unit.troopId, unitName = name, unneeded = true))
        if (res.blocked != null) {
            log("Не продаю «$name» ($where): ${res.blocked}")
            decisions?.outcome(did, false, "продажа не начиналась: ${res.blocked}"); combo = null
            return
        }
        if (res.success) {
            log("Продал с поля «$name» ($where), способ: ${res.method?.title ?: "воин уже исчез"} — $reason")
            board.remove(p.index); swapFails = 0; boardFullHint = false
            placeGate.reset(); counter = null; counterAt = 0L; elixirCache = null; ignoreFullUntil = now + 800
            decisions?.outcome(did, true, "клетка опустела: способ ${res.method?.title ?: "воин уже исчез"}")
        } else if (!res.aborted) {
            swapFails++
            log("Не удалось убрать «$name» ($where) ни одним из трёх способов")
            decisions?.outcome(did, false, "не удалось убрать с поля"); combo = null
        }
    }

    /** Следующий шаг начатой замены. true — кадр занят этим шагом. */
    private suspend fun runCombo(k: LoopKnowledge, cards: List<ShopCard>, bench: BooleanArray, bmp: Bitmap, w: Int, h: Int, now: Long): Boolean {
        val c = combo ?: return false
        if (now > c.until) {
            combo = null; log("Замена не завершилась вовремя — пересчитываю"); decisions?.outcome(c.did, false, "замена не завершена за 12 с")
            return false
        }
        if (c.sales.isNotEmpty()) {
            val p = c.sales[0]
            val there = if (p.where == Where.BENCH) bench.getOrElse(p.index) { false }
            else board.containsKey(p.index) && PixelOps.cellOccupied(bmp, HexGrid.cells[p.index])
            if (!there) {
                combo = null; log("Войско для продажи уже не на месте — пересчитываю"); decisions?.outcome(c.did, false, "войско ушло с места до продажи")
                return false
            }
            c.sales.removeAt(0)
            sellPiece(k, p, c.reason, c.details, c.did, bmp, w, h, now)
            return true
        }
        val sig = c.buySig
        if (sig == null) { combo = null; return false }
        val card = cards.firstOrNull { close(it.sig, sig) }
        if (card == null) {
            combo = null; log("Карточка для покупки исчезла из магазина — пересчитываю"); decisions?.outcome(c.did, false, "карточка пропала из магазина")
            return false
        }
        if (!card.affordable) return true // эликсир после продажи ещё не обновился
        combo = null
        buyCard(k, card, w, h, c.reason, c.details, c.did)
        return true
    }
}
